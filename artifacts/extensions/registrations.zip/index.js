"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var registrations_exports = {};
__export(registrations_exports, {
  main: () => main
});
module.exports = __toCommonJS(registrations_exports);
var import_wx_server_sdk = __toESM(require("wx-server-sdk"));
var import_zod = require("zod");
import_wx_server_sdk.default.init({ env: import_wx_server_sdk.default.DYNAMIC_CURRENT_ENV });
var db = import_wx_server_sdk.default.database();
var ListSchema = import_zod.z.object({
  activityId: import_zod.z.string().optional(),
  userId: import_zod.z.string().optional(),
  status: import_zod.z.enum(["registered", "waitlist", "cancelled"]).optional()
}).partial();
var RegisterSchema = import_zod.z.object({ activityId: import_zod.z.string() });
var CancelSchema = import_zod.z.object({ activityId: import_zod.z.string() });
var CheckinSchema = import_zod.z.object({ activityId: import_zod.z.string(), userId: import_zod.z.string().optional() });
var main = async (event) => {
  var _a, _b, _c, _d;
  try {
    const { action, payload } = event || {};
    const ctx = ((_b = (_a = import_wx_server_sdk.default).getWXContext) == null ? void 0 : _b.call(_a)) || {};
    const OPENID = ctx.OPENID;
    const now = Date.now();
    const isRole = async (role) => {
      var _a2, _b2, _c2, _d2, _e;
      try {
        if (!OPENID)
          return false;
        const _ = db.command;
        if (role === "admin") {
          const byOpenId = await db.collection("Users").where({ openId: OPENID, role: "admin" }).limit(1).get();
          if ((_a2 = byOpenId.data) == null ? void 0 : _a2.length)
            return true;
          const byId = await db.collection("Users").where({ _id: OPENID, role: "admin" }).limit(1).get();
          if ((_b2 = byId.data) == null ? void 0 : _b2.length)
            return true;
          const byRoles = await db.collection("Users").where({ openId: OPENID, roles: _.in(["admin"]) }).limit(1).get();
          if ((_c2 = byRoles.data) == null ? void 0 : _c2.length)
            return true;
          return false;
        }
        if (role === "social_worker") {
          const byOpenId = await db.collection("Users").where({ openId: OPENID, role: "social_worker" }).limit(1).get();
          if ((_d2 = byOpenId.data) == null ? void 0 : _d2.length)
            return true;
          const byRoles = await db.collection("Users").where({ openId: OPENID, roles: _.in(["social_worker"]) }).limit(1).get();
          if ((_e = byRoles.data) == null ? void 0 : _e.length)
            return true;
          return false;
        }
      } catch {
      }
      return false;
    };
    const canManage = async () => await isRole("admin") || await isRole("social_worker");
    switch (action) {
      case "list": {
        const q = ListSchema.parse(payload || {});
        const _ = db.command;
        const query = {};
        if (q.activityId)
          query.activityId = q.activityId;
        if (q.userId)
          query.userId = q.userId === "me" ? OPENID : q.userId;
        if (q.status)
          query.status = q.status;
        const res = await db.collection("Registrations").where(query).orderBy("createdAt", "desc").get();
        return { ok: true, data: res.data };
      }
      case "register": {
        const { activityId } = RegisterSchema.parse(payload || {});
        if (!OPENID)
          return { ok: false, error: { code: "E_AUTH", msg: "\u8BF7\u5148\u767B\u5F55" } };
        const trx = await db.startTransaction();
        try {
          const actRes = await trx.collection("Activities").doc(activityId).get();
          const activity = actRes == null ? void 0 : actRes.data;
          if (!activity) {
            await trx.rollback();
            return { ok: false, error: { code: "E_NOT_FOUND", msg: "\u6D3B\u52A8\u4E0D\u5B58\u5728" } };
          }
          const capacity = typeof activity.capacity === "number" ? activity.capacity : 0;
          const existRes = await trx.collection("Registrations").where({ activityId, userId: OPENID }).limit(1).get();
          const exist = existRes.data && existRes.data[0] || null;
          if (exist && (exist.status === "registered" || exist.status === "waitlist")) {
            await trx.commit();
            return { ok: false, error: { code: "E_CONFLICT", msg: exist.status === "registered" ? "\u5DF2\u62A5\u540D" : "\u5DF2\u5728\u5019\u8865" } };
          }
          let registeredCount = 0;
          try {
            const c = await trx.collection("Registrations").where({ activityId, status: "registered" }).count();
            registeredCount = (c.total ?? c.count) || 0;
          } catch {
          }
          const isUnlimited = capacity === 0;
          const canRegister = isUnlimited || registeredCount < capacity;
          if (exist) {
            await trx.collection("Registrations").doc(exist._id).update({ data: { status: canRegister ? "registered" : "waitlist", registeredAt: canRegister ? now : null, createdAt: exist.createdAt || now } });
            await trx.commit();
            return { ok: true, data: { status: canRegister ? "registered" : "waitlist" } };
          } else {
            const doc = { activityId, userId: OPENID, status: canRegister ? "registered" : "waitlist", createdAt: now };
            if (canRegister)
              doc.registeredAt = now;
            const addRes = await trx.collection("Registrations").add({ data: doc });
            await trx.commit();
            return { ok: true, data: { _id: addRes._id, status: doc.status } };
          }
        } catch (e) {
          try {
            await ((_c = db.runTransaction) == null ? void 0 : _c.call(db, () => Promise.resolve()));
          } catch {
          }
          return { ok: false, error: { code: e.code || "E_INTERNAL", msg: e.message } };
        }
      }
      case "cancel": {
        const { activityId } = CancelSchema.parse(payload || {});
        if (!OPENID)
          return { ok: false, error: { code: "E_AUTH", msg: "\u8BF7\u5148\u767B\u5F55" } };
        const trx = await db.startTransaction();
        try {
          const regRes = await trx.collection("Registrations").where({ activityId, userId: OPENID }).limit(1).get();
          const reg = regRes.data && regRes.data[0] || null;
          if (!reg) {
            await trx.rollback();
            return { ok: false, error: { code: "E_NOT_FOUND", msg: "\u672A\u62A5\u540D" } };
          }
          if (reg.status === "cancelled") {
            await trx.commit();
            return { ok: true, data: { updated: 0 } };
          }
          await trx.collection("Registrations").doc(reg._id).update({ data: { status: "cancelled", cancelledAt: now } });
          const actRes = await trx.collection("Activities").doc(activityId).get();
          const activity = actRes == null ? void 0 : actRes.data;
          const capacity = typeof (activity == null ? void 0 : activity.capacity) === "number" ? activity.capacity : 0;
          const isUnlimited = capacity === 0;
          if (!isUnlimited) {
            let registeredCount = 0;
            try {
              const c = await trx.collection("Registrations").where({ activityId, status: "registered" }).count();
              registeredCount = (c.total ?? c.count) || 0;
            } catch {
            }
            if (registeredCount < capacity) {
              const wl = await trx.collection("Registrations").where({ activityId, status: "waitlist" }).orderBy("createdAt", "asc").limit(1).get();
              const first = wl.data && wl.data[0] || null;
              if (first) {
                await trx.collection("Registrations").doc(first._id).update({ data: { status: "registered", registeredAt: now } });
              }
            }
          }
          await trx.commit();
          return { ok: true, data: { updated: 1 } };
        } catch (e) {
          try {
            await ((_d = db.runTransaction) == null ? void 0 : _d.call(db, () => Promise.resolve()));
          } catch {
          }
          return { ok: false, error: { code: e.code || "E_INTERNAL", msg: e.message } };
        }
      }
      case "checkin": {
        const { activityId, userId } = CheckinSchema.parse(payload || {});
        const targetUserId = userId || OPENID;
        if (!targetUserId)
          return { ok: false, error: { code: "E_AUTH", msg: "\u8BF7\u5148\u767B\u5F55" } };
        if (userId && !await canManage())
          return { ok: false, error: { code: "E_PERM", msg: "\u4EC5\u7BA1\u7406\u5458/\u793E\u5DE5\u53EF\u4E3A\u4ED6\u4EBA\u7B7E\u5230" } };
        const regRes = await db.collection("Registrations").where({ activityId, userId: targetUserId }).limit(1).get();
        const reg = regRes.data && regRes.data[0] || null;
        if (!reg)
          return { ok: false, error: { code: "E_NOT_FOUND", msg: "\u672A\u62A5\u540D" } };
        if (reg.checkedInAt)
          return { ok: true, data: { updated: 0 } };
        await db.collection("Registrations").doc(reg._id).update({ data: { checkedInAt: now } });
        return { ok: true, data: { updated: 1 } };
      }
      default:
        return { ok: false, error: { code: "E_ACTION", msg: "unknown action" } };
    }
  } catch (e) {
    return { ok: false, error: { code: e.code || "E_INTERNAL", msg: e.message, details: e.stack } };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=index.js.map