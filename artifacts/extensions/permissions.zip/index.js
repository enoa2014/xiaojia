"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var permissions_exports = {};
__export(permissions_exports, {
  main: () => main
});
module.exports = __toCommonJS(permissions_exports);
var import_wx_server_sdk = __toESM(require("wx-server-sdk"));
var import_zod = require("zod");
import_wx_server_sdk.default.init({ env: import_wx_server_sdk.default.DYNAMIC_CURRENT_ENV });
var db = import_wx_server_sdk.default.database();
var SubmitSchema = import_zod.z.object({
  fields: import_zod.z.array(import_zod.z.enum(["id_card", "phone", "diagnosis"])).nonempty(),
  patientId: import_zod.z.string().min(1),
  reason: import_zod.z.string().min(20),
  expiresDays: import_zod.z.enum(["30", "60", "90"]).transform(Number).optional()
});
var ApproveSchema = import_zod.z.object({ id: import_zod.z.string(), expiresAt: import_zod.z.number().optional() });
var RejectSchema = import_zod.z.object({ id: import_zod.z.string(), reason: import_zod.z.string().min(20).max(200) });
var ListSchema = import_zod.z.object({
  page: import_zod.z.number().int().min(1).default(1),
  pageSize: import_zod.z.number().int().min(1).max(100).default(20),
  filter: import_zod.z.object({ requesterId: import_zod.z.string().optional(), patientId: import_zod.z.string().optional(), status: import_zod.z.enum(["pending", "approved", "rejected"]).optional() }).partial().optional()
});
var main = async (event) => {
  var _a, _b, _c, _d;
  try {
    const { action, payload } = event || {};
    const { OPENID } = ((_b = (_a = import_wx_server_sdk.default).getWXContext) == null ? void 0 : _b.call(_a)) || {};
    const isAdmin = async () => {
      try {
        if (!OPENID)
          return false;
        const _ = db.command;
        const byOpenId = await db.collection("Users").where({ openId: OPENID, role: "admin" }).limit(1).get();
        if (byOpenId.data && byOpenId.data.length)
          return true;
        const byId = await db.collection("Users").where({ _id: OPENID, role: "admin" }).limit(1).get();
        if (byId.data && byId.data.length)
          return true;
        const byRoles = await db.collection("Users").where({ openId: OPENID, roles: _.in(["admin"]) }).limit(1).get();
        if (byRoles.data && byRoles.data.length)
          return true;
      } catch {
      }
      return false;
    };
    switch (action) {
      case "request.submit": {
        const parsed = SubmitSchema.safeParse(payload || {});
        if (!parsed.success)
          return { ok: false, error: { code: "E_VALIDATE", msg: "\u8BF7\u5B8C\u5584\u7533\u8BF7\u4FE1\u606F\uFF08\u5B57\u6BB5/\u7406\u7531/\u6709\u6548\u671F\uFF09", details: parsed.error.issues } };
        const p = parsed.data;
        const { OPENID: OPENID2 } = ((_d = (_c = import_wx_server_sdk.default).getWXContext) == null ? void 0 : _d.call(_c)) || {};
        if (!OPENID2)
          return { ok: false, error: { code: "E_AUTH", msg: "\u8BF7\u5148\u767B\u5F55" } };
        const now = Date.now();
        const expiresDays = p.expiresDays || 30;
        const requestedExpiresAt = now + expiresDays * 24 * 60 * 60 * 1e3;
        const doc = {
          requesterId: OPENID2,
          patientId: p.patientId,
          fields: p.fields,
          reason: p.reason,
          status: "pending",
          requestedExpiresAt,
          createdAt: now
        };
        const res = await db.collection("PermissionRequests").add({ data: doc });
        return { ok: true, data: { _id: res._id, expiresAt: requestedExpiresAt } };
      }
      case "request.approve": {
        const parsed = ApproveSchema.safeParse(payload || {});
        if (!parsed.success)
          return { ok: false, error: { code: "E_VALIDATE", msg: "\u53C2\u6570\u4E0D\u5408\u6CD5", details: parsed.error.issues } };
        const { id, expiresAt } = parsed.data;
        if (!await isAdmin())
          return { ok: false, error: { code: "E_PERM", msg: "\u9700\u8981\u7BA1\u7406\u5458\u6743\u9650" } };
        const now = Date.now();
        const exp = expiresAt && expiresAt > now ? expiresAt : now + 30 * 24 * 60 * 60 * 1e3;
        await db.collection("PermissionRequests").doc(id).update({ data: { status: "approved", expiresAt: exp, approvedAt: now, approvedBy: OPENID || null } });
        try {
          await db.collection("AuditLogs").add({ data: { actorId: OPENID || null, action: "permissions.approve", target: { requestId: id }, createdAt: now } });
        } catch {
        }
        return { ok: true, data: { updated: 1 } };
      }
      case "request.reject": {
        const parsed = RejectSchema.safeParse(payload || {});
        if (!parsed.success)
          return { ok: false, error: { code: "E_VALIDATE", msg: "\u53C2\u6570\u4E0D\u5408\u6CD5", details: parsed.error.issues } };
        const { id, reason } = parsed.data;
        if (!await isAdmin())
          return { ok: false, error: { code: "E_PERM", msg: "\u9700\u8981\u7BA1\u7406\u5458\u6743\u9650" } };
        const now = Date.now();
        await db.collection("PermissionRequests").doc(id).update({ data: { status: "rejected", rejectedAt: now, rejectedBy: OPENID || null, rejectReason: reason } });
        try {
          await db.collection("AuditLogs").add({ data: { actorId: OPENID || null, action: "permissions.reject", target: { requestId: id }, createdAt: now } });
        } catch {
        }
        return { ok: true, data: { updated: 1 } };
      }
      case "request.list": {
        const qp = ListSchema.safeParse(payload || {});
        if (!qp.success)
          return { ok: false, error: { code: "E_VALIDATE", msg: "\u53C2\u6570\u4E0D\u5408\u6CD5", details: qp.error.issues } };
        const q = qp.data;
        let where = {};
        if (q.filter) {
          const f = q.filter;
          if (f.requesterId)
            where.requesterId = f.requesterId;
          if (f.patientId)
            where.patientId = f.patientId;
          if (f.status)
            where.status = f.status;
        }
        if (!await isAdmin()) {
          where.requesterId = OPENID;
        }
        const res = await db.collection("PermissionRequests").where(where).orderBy("createdAt", "desc").skip((q.page - 1) * q.pageSize).limit(q.pageSize).get();
        return { ok: true, data: res.data };
      }
      default:
        return { ok: false, error: { code: "E_ACTION", msg: "unsupported action" } };
    }
  } catch (e) {
    return { ok: false, error: { code: e.code || "E_INTERNAL", msg: e.message, details: e.stack } };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=index.js.map