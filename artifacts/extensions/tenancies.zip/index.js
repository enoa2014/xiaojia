"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var tenancies_exports = {};
__export(tenancies_exports, {
  main: () => main
});
module.exports = __toCommonJS(tenancies_exports);
var import_wx_server_sdk = __toESM(require("wx-server-sdk"));
var import_zod2 = require("zod");

// schema.ts
var import_zod = require("zod");
var TenanciesListSchema = import_zod.z.object({
  page: import_zod.z.number().int().min(1).default(1),
  pageSize: import_zod.z.number().int().min(1).max(100).default(10)
});
var TenancyCreateSchema = import_zod.z.object({
  patientId: import_zod.z.string().optional(),
  id_card: import_zod.z.string().regex(/^\d{6}(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/).optional(),
  checkInDate: import_zod.z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  checkOutDate: import_zod.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  room: import_zod.z.string().optional(),
  bed: import_zod.z.string().optional(),
  subsidy: import_zod.z.number().min(0).optional(),
  extra: import_zod.z.object({ admitPersons: import_zod.z.string().optional() }).partial().optional()
});
var TenancyUpdateSchema = import_zod.z.object({
  id: import_zod.z.string(),
  patch: TenancyCreateSchema.partial()
});

// index.ts
import_wx_server_sdk.default.init({ env: import_wx_server_sdk.default.DYNAMIC_CURRENT_ENV });
var db = import_wx_server_sdk.default.database();
var IdSchema = import_zod2.z.object({ id: import_zod2.z.string() });
var main = async (event) => {
  try {
    const { action, payload } = event || {};
    switch (action) {
      case "list": {
        const qp = TenanciesListSchema.parse(payload || {});
        const res = await db.collection("Tenancies").orderBy("checkInDate", "desc").skip((qp.page - 1) * qp.pageSize).limit(qp.pageSize).get();
        return { ok: true, data: res.data };
      }
      case "get": {
        const { id } = IdSchema.parse(payload || {});
        const r = await db.collection("Tenancies").doc(id).get();
        if (!(r == null ? void 0 : r.data))
          return { ok: false, error: { code: "E_NOT_FOUND", msg: "tenancy not found" } };
        return { ok: true, data: r.data };
      }
      case "create": {
        const t = TenancyCreateSchema.parse((payload == null ? void 0 : payload.tenancy) || payload || {});
        if (!t.patientId && !t.id_card)
          return { ok: false, error: { code: "E_VALIDATE", msg: "patientId \u6216 id_card \u5FC5\u586B" } };
        if (t.checkOutDate && t.checkOutDate < t.checkInDate)
          return { ok: false, error: { code: "E_VALIDATE", msg: "\u9000\u4F4F\u65E5\u671F\u4E0D\u80FD\u65E9\u4E8E\u5165\u4F4F\u65E5\u671F" } };
        const doc = { ...t, createdAt: Date.now() };
        const { _id } = await db.collection("Tenancies").add({ data: doc });
        return { ok: true, data: { _id } };
      }
      case "update": {
        const { id, patch } = TenancyUpdateSchema.parse(payload || {});
        if (patch.checkInDate && patch.checkOutDate && patch.checkOutDate < patch.checkInDate) {
          return { ok: false, error: { code: "E_VALIDATE", msg: "\u9000\u4F4F\u65E5\u671F\u4E0D\u80FD\u65E9\u4E8E\u5165\u4F4F\u65E5\u671F" } };
        }
        await db.collection("Tenancies").doc(id).update({ data: patch });
        return { ok: true, data: { updated: 1 } };
      }
      default:
        return { ok: false, error: { code: "E_ACTION", msg: "unknown action" } };
    }
  } catch (e) {
    return { ok: false, error: { code: e.code || "E_INTERNAL", msg: e.message, details: e.stack } };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=index.js.map