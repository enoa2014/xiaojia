"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var activities_exports = {};
__export(activities_exports, {
  main: () => main
});
module.exports = __toCommonJS(activities_exports);
var import_wx_server_sdk = __toESM(require("wx-server-sdk"));
var import_zod2 = require("zod");

// schema.ts
var import_zod = require("zod");
var ActivitiesListSchema = import_zod.z.object({
  page: import_zod.z.number().int().min(1).default(1),
  pageSize: import_zod.z.number().int().min(1).max(100).default(10),
  filter: import_zod.z.object({
    status: import_zod.z.enum(["open", "ongoing", "done", "closed"]).optional(),
    from: import_zod.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    to: import_zod.z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional()
  }).partial().optional(),
  sort: import_zod.z.record(import_zod.z.string(), import_zod.z.union([import_zod.z.literal(1), import_zod.z.literal(-1)])).optional()
});
var ActivityCreateSchema = import_zod.z.object({
  title: import_zod.z.string().min(2).max(40),
  date: import_zod.z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  location: import_zod.z.string().min(1).max(80),
  capacity: import_zod.z.number().int().min(0),
  status: import_zod.z.enum(["open", "ongoing", "done", "closed"]).default("open"),
  description: import_zod.z.string().max(500).optional()
});

// index.ts
import_wx_server_sdk.default.init({ env: import_wx_server_sdk.default.DYNAMIC_CURRENT_ENV });
var db = import_wx_server_sdk.default.database();
var IdSchema = import_zod2.z.object({ id: import_zod2.z.string() });
var main = async (event) => {
  var _a, _b;
  try {
    const { action, payload } = event || {};
    const { OPENID } = ((_b = (_a = import_wx_server_sdk.default).getWXContext) == null ? void 0 : _b.call(_a)) || {};
    const isRole = async (role) => {
      var _a2, _b2, _c, _d, _e;
      try {
        if (!OPENID)
          return false;
        const _ = db.command;
        if (role === "admin") {
          const byOpenId = await db.collection("Users").where({ openId: OPENID, role: "admin" }).limit(1).get();
          if ((_a2 = byOpenId.data) == null ? void 0 : _a2.length)
            return true;
          const byId = await db.collection("Users").where({ _id: OPENID, role: "admin" }).limit(1).get();
          if ((_b2 = byId.data) == null ? void 0 : _b2.length)
            return true;
          const byRoles = await db.collection("Users").where({ openId: OPENID, roles: _.in(["admin"]) }).limit(1).get();
          if ((_c = byRoles.data) == null ? void 0 : _c.length)
            return true;
          return false;
        }
        if (role === "social_worker") {
          const byOpenId = await db.collection("Users").where({ openId: OPENID, role: "social_worker" }).limit(1).get();
          if ((_d = byOpenId.data) == null ? void 0 : _d.length)
            return true;
          const byRoles = await db.collection("Users").where({ openId: OPENID, roles: _.in(["social_worker"]) }).limit(1).get();
          if ((_e = byRoles.data) == null ? void 0 : _e.length)
            return true;
          return false;
        }
      } catch {
      }
      return false;
    };
    const canCreate = async () => await isRole("admin") || await isRole("social_worker");
    switch (action) {
      case "list": {
        const qp = ActivitiesListSchema.parse(payload || {});
        const _ = db.command;
        let query = {};
        if (qp.filter) {
          const f = qp.filter;
          if (f.status)
            query.status = f.status;
          if (f.from || f.to) {
            const range = {};
            if (f.from)
              range[_.gte] = f.from;
            if (f.to)
              range[_.lte] = f.to;
            query.date = range;
          }
        }
        let coll = db.collection("Activities").where(query);
        if (qp.sort && Object.keys(qp.sort).length) {
          const [k, v] = Object.entries(qp.sort)[0];
          coll = coll.orderBy(k, v === -1 ? "desc" : "asc");
        } else {
          coll = coll.orderBy("date", "desc");
        }
        let total = 0;
        try {
          const c = await db.collection("Activities").where(query).count();
          total = (c.total ?? c.count) || 0;
        } catch {
        }
        const res = await coll.skip((qp.page - 1) * qp.pageSize).limit(qp.pageSize).get();
        const items = res.data;
        const hasMore = qp.page * qp.pageSize < total;
        return { ok: true, data: { items, meta: { total, hasMore } } };
      }
      case "get": {
        const { id } = IdSchema.parse(payload || {});
        const r = await db.collection("Activities").doc(id).get();
        if (!(r == null ? void 0 : r.data))
          return { ok: false, error: { code: "E_NOT_FOUND", msg: "activity not found" } };
        return { ok: true, data: r.data };
      }
      case "create": {
        if (!await canCreate())
          return { ok: false, error: { code: "E_PERM", msg: "\u4EC5\u7BA1\u7406\u5458/\u793E\u5DE5\u53EF\u53D1\u5E03\u6D3B\u52A8" } };
        const parsed = ActivityCreateSchema.safeParse((payload == null ? void 0 : payload.activity) || payload || {});
        if (!parsed.success) {
          const issues = parsed.error.issues || [];
          const first = issues[0];
          const path = first && first.path && first.path.join(".") || "";
          let msg = "\u586B\u5199\u6709\u8BEF";
          if (path.includes("title"))
            msg = "\u6807\u9898\u9700 2\u201340 \u5B57";
          else if (path.includes("date"))
            msg = "\u8BF7\u9009\u62E9\u65E5\u671F";
          else if (path.includes("location"))
            msg = "\u5730\u70B9\u9700 \u226480 \u5B57";
          else if (path.includes("capacity"))
            msg = "\u5BB9\u91CF\u9700\u4E3A \u22650 \u7684\u6574\u6570";
          else if (path.includes("status"))
            msg = "\u72B6\u6001\u4E0D\u5408\u6CD5";
          return { ok: false, error: { code: "E_VALIDATE", msg, details: issues } };
        }
        const a = parsed.data;
        const doc = { ...a, createdAt: Date.now() };
        const { _id } = await db.collection("Activities").add({ data: doc });
        return { ok: true, data: { _id } };
      }
      default:
        return { ok: false, error: { code: "E_ACTION", msg: "unknown action" } };
    }
  } catch (e) {
    return { ok: false, error: { code: e.code || "E_INTERNAL", msg: e.message, details: e.stack } };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=index.js.map