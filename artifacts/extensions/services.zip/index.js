"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var services_exports = {};
__export(services_exports, {
  main: () => main
});
module.exports = __toCommonJS(services_exports);
var import_wx_server_sdk = __toESM(require("wx-server-sdk"));
var import_zod2 = require("zod");

// schema.ts
var import_zod = require("zod");
var ServicesListSchema = import_zod.z.object({
  page: import_zod.z.number().int().min(1).default(1),
  pageSize: import_zod.z.number().int().min(1).max(100).default(10),
  filter: import_zod.z.object({
    patientId: import_zod.z.string().min(1).max(64).optional(),
    createdBy: import_zod.z.string().min(1).max(128).optional(),
    type: import_zod.z.enum(["visit", "psych", "goods", "referral", "followup"]).optional(),
    status: import_zod.z.enum(["review", "approved", "rejected"]).optional()
  }).partial().optional(),
  sort: import_zod.z.record(import_zod.z.string(), import_zod.z.union([import_zod.z.literal(1), import_zod.z.literal(-1)])).optional()
});
var ServiceCreateSchema = import_zod.z.object({
  patientId: import_zod.z.string(),
  type: import_zod.z.enum(["visit", "psych", "goods", "referral", "followup"]),
  date: import_zod.z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  desc: import_zod.z.string().max(500).optional(),
  images: import_zod.z.array(import_zod.z.string()).max(9).optional()
});
var ServiceReviewSchema = import_zod.z.object({
  id: import_zod.z.string(),
  decision: import_zod.z.enum(["approved", "rejected"]),
  reason: import_zod.z.string().min(20).max(200).optional()
});

// index.ts
import_wx_server_sdk.default.init({ env: import_wx_server_sdk.default.DYNAMIC_CURRENT_ENV });
var db = import_wx_server_sdk.default.database();
var IdSchema = import_zod2.z.object({ id: import_zod2.z.string() });
var main = async (event) => {
  var _a, _b, _c, _d, _e, _f;
  try {
    const { action, payload } = event || {};
    const { OPENID } = ((_b = (_a = import_wx_server_sdk.default).getWXContext) == null ? void 0 : _b.call(_a)) || {};
    const isRole = async (role) => {
      var _a2, _b2, _c2, _d2, _e2;
      try {
        if (!OPENID)
          return false;
        const _ = db.command;
        if (role === "admin") {
          const byOpenId = await db.collection("Users").where({ openId: OPENID, role: "admin" }).limit(1).get();
          if ((_a2 = byOpenId.data) == null ? void 0 : _a2.length)
            return true;
          const byId = await db.collection("Users").where({ _id: OPENID, role: "admin" }).limit(1).get();
          if ((_b2 = byId.data) == null ? void 0 : _b2.length)
            return true;
          const byRoles = await db.collection("Users").where({ openId: OPENID, roles: _.in(["admin"]) }).limit(1).get();
          if ((_c2 = byRoles.data) == null ? void 0 : _c2.length)
            return true;
          return false;
        }
        if (role === "social_worker") {
          const byOpenId = await db.collection("Users").where({ openId: OPENID, role: "social_worker" }).limit(1).get();
          if ((_d2 = byOpenId.data) == null ? void 0 : _d2.length)
            return true;
          const byRoles = await db.collection("Users").where({ openId: OPENID, roles: _.in(["social_worker"]) }).limit(1).get();
          if ((_e2 = byRoles.data) == null ? void 0 : _e2.length)
            return true;
          return false;
        }
      } catch {
      }
      return false;
    };
    const canReview = async () => await isRole("admin") || await isRole("social_worker");
    switch (action) {
      case "list": {
        const qp = ServicesListSchema.parse(payload || {});
        const { OPENID: OPENID2 } = ((_d = (_c = import_wx_server_sdk.default).getWXContext) == null ? void 0 : _d.call(_c)) || {};
        let query = {};
        if (qp.filter) {
          const f = qp.filter;
          if (f.patientId)
            query.patientId = f.patientId;
          if (f.createdBy)
            query.createdBy = f.createdBy === "me" && OPENID2 ? OPENID2 : f.createdBy;
          if (f.type)
            query.type = f.type;
          if (f.status)
            query.status = f.status;
        }
        let coll = db.collection("Services").where(query);
        if (qp.sort && Object.keys(qp.sort).length) {
          const [k, v] = Object.entries(qp.sort)[0];
          coll = coll.orderBy(k, v === -1 ? "desc" : "asc");
        } else {
          coll = coll.orderBy("date", "desc");
        }
        const res = await coll.skip((qp.page - 1) * qp.pageSize).limit(qp.pageSize).get();
        return { ok: true, data: res.data };
      }
      case "get": {
        const { id } = IdSchema.parse(payload || {});
        const r = await db.collection("Services").doc(id).get();
        if (!(r == null ? void 0 : r.data))
          return { ok: false, error: { code: "E_NOT_FOUND", msg: "service not found" } };
        return { ok: true, data: r.data };
      }
      case "create": {
        const parsed = ServiceCreateSchema.safeParse((payload == null ? void 0 : payload.service) || payload || {});
        if (!parsed.success) {
          const issues = parsed.error.issues || [];
          const first = issues[0];
          const path = first && first.path && first.path.join(".") || "";
          let msg = "\u586B\u5199\u6709\u8BEF";
          if (path.includes("patientId"))
            msg = "\u8BF7\u5148\u9009\u62E9\u60A3\u8005";
          else if (path.includes("type"))
            msg = "\u8BF7\u9009\u62E9\u670D\u52A1\u7C7B\u578B";
          else if (path.includes("date"))
            msg = "\u8BF7\u9009\u62E9\u65E5\u671F";
          else if (path.includes("images"))
            msg = "\u56FE\u7247\u6570\u91CF\u6216\u683C\u5F0F\u4E0D\u5408\u6CD5";
          return { ok: false, error: { code: "E_VALIDATE", msg, details: issues } };
        }
        const s = parsed.data;
        const clientToken = payload && payload.clientToken || null;
        const { OPENID: OPENID2 } = ((_f = (_e = import_wx_server_sdk.default).getWXContext) == null ? void 0 : _f.call(_e)) || {};
        if (clientToken) {
          const existed = await db.collection("Services").where({ clientToken }).limit(1).get();
          if (existed.data && existed.data.length) {
            return { ok: true, data: { _id: existed.data[0]._id } };
          }
        }
        const doc = { ...s, status: "review", createdBy: OPENID2 || null, createdAt: Date.now(), ...clientToken ? { clientToken } : {} };
        const { _id } = await db.collection("Services").add({ data: doc });
        return { ok: true, data: { _id } };
      }
      case "review": {
        const { id, decision, reason } = ServiceReviewSchema.parse(payload || {});
        if (!await canReview())
          return { ok: false, error: { code: "E_PERM", msg: "\u9700\u8981\u5BA1\u6838\u6743\u9650" } };
        if (decision === "rejected" && !reason)
          return { ok: false, error: { code: "E_VALIDATE", msg: "\u5BA1\u6838\u9A73\u56DE\u9700\u586B\u5199\u7406\u7531" } };
        const r = await db.collection("Services").doc(id).get();
        const cur = r == null ? void 0 : r.data;
        if (!cur)
          return { ok: false, error: { code: "E_NOT_FOUND", msg: "service not found" } };
        if (cur.status !== "review")
          return { ok: false, error: { code: "E_CONFLICT", msg: "\u5F53\u524D\u72B6\u6001\u4E0D\u53EF\u5BA1\u6838" } };
        await db.collection("Services").doc(id).update({ data: { status: decision, reviewReason: reason || null, reviewedAt: Date.now() } });
        try {
          await db.collection("AuditLogs").add({ data: { actorId: OPENID || null, action: "services.review", target: { id, decision }, createdAt: Date.now() } });
        } catch {
        }
        return { ok: true, data: { updated: 1 } };
      }
      default:
        return { ok: false, error: { code: "E_ACTION", msg: "unknown action" } };
    }
  } catch (e) {
    return { ok: false, error: { code: e.code || "E_INTERNAL", msg: e.message, details: e.stack } };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
//# sourceMappingURL=index.js.map